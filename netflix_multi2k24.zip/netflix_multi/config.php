<?php 

//Have a telegram bot? put the tokens here :D
$bot = "token";
$chat_ids = array("chatid");


//secodns of waiting
$seconds = 5;


?>